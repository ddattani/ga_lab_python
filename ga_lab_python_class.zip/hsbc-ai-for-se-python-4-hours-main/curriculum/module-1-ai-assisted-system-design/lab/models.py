from datetime import datetime
from enum import Enum

from pydantic import BaseModel, Field, field_validator


class PaymentState(str, Enum):
    submitted = "submitted"
    settled = "settled"
    failed = "failed"


class PaymentEvent(BaseModel):
    event_id: str = Field(min_length=1, max_length=64)
    payment_id: str = Field(min_length=1, max_length=64)
    state: PaymentState
    occurred_at: datetime

    @field_validator("occurred_at")
    @classmethod
    def require_timezone(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("occurred_at must include timezone information")
        return value


class PaymentStatus(BaseModel):
    payment_id: str = Field(min_length=1, max_length=64)
    state: PaymentState
    updated_at: datetime

    @field_validator("updated_at")
    @classmethod
    def require_timezone(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("updated_at must include timezone information")
        return value


class ErrorResponse(BaseModel):
    code: str | None = None
    message: str | None = None
