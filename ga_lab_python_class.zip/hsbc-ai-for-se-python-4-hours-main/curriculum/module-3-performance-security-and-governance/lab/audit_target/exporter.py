"""Builds the text statement that is sent to a client."""
import logging

log = logging.getLogger(__name__)


def render_statement(account_number: str, rows: list[dict]) -> str:
    masked_account = "*" * max(0, len(account_number) - 4) + account_number[-4:]
    log.info("Exporting statement for account %s", masked_account)
    lines = [f"Account: {masked_account}"]
    for row in rows:
        lines.append(f"{row['id']} {row['amount']} {row['currency']}")
    return "\n".join(lines)
