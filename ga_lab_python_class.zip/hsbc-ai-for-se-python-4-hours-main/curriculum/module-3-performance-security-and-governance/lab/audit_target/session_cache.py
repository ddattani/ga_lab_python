"""Stores a user's session between requests."""
import json


def save(session: dict) -> bytes:
    return json.dumps(session).encode("utf-8")


def load(data: bytes) -> dict:
    try:
        session = json.loads(data)
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise ValueError("Session data must be valid JSON.") from None
    if not isinstance(session, dict):
        raise ValueError("Session data must be a JSON object.")
    return session
