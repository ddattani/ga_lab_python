"""Service configuration."""
import os

def db_password(environ=os.environ) -> str:
    value = environ.get("DB_PASSWORD")
    if value is None or not value.strip():
        raise RuntimeError("DB_PASSWORD is not configured.") from None
    return value


def pricing_api_key(environ=os.environ) -> str:
    value = environ.get("PRICING_API_KEY")
    if value is None or not value.strip():
        raise RuntimeError("PRICING_API_KEY is not configured.") from None
    return value
