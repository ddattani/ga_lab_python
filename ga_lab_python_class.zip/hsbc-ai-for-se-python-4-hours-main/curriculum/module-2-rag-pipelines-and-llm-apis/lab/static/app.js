const askForm = document.querySelector("#ask-form");
const questionInput = document.querySelector("#question");
const askButton = document.querySelector("#ask-button");
const notice = document.querySelector("#notice");
const answerSection = document.querySelector("#answer-section");
const reviewList = document.querySelector("#review-list");
const pendingCount = document.querySelector("#pending-count");

function showNotice(message, isError = false) {
  notice.textContent = message;
  notice.classList.toggle("error", isError);
  notice.hidden = false;
}

function makeElement(tag, className, text) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (text !== undefined) element.textContent = text;
  return element;
}

async function requestJson(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { "Content-Type": "application/json", ...options.headers },
  });
  const body = await response.json();
  if (!response.ok) {
    const detail = typeof body.detail === "string" ? body.detail : "The request could not be completed.";
    throw new Error(detail);
  }
  return body;
}

function renderSources(sources, container) {
  container.replaceChildren();
  for (const source of sources) {
    const card = makeElement("article", "source-card");
    const meta = makeElement("div", "source-meta");
    meta.append(
      makeElement("span", "source-name", `${source.doc_name} · chunk ${source.chunk_no}`),
      makeElement("span", "score", `Relevance ${Number(source.score).toFixed(3)}`),
    );
    card.append(meta, makeElement("p", "source-text", source.text));
    container.append(card);
  }
}

function renderAnswer(result) {
  answerSection.hidden = false;
  document.querySelector("#answer-question").textContent = `Question: ${result.question}`;
  document.querySelector("#answer-text").textContent = result.answer;
  const status = document.querySelector("#answer-status");
  status.className = "status-badge";
  if (result.grounded) {
    status.textContent = `Draft · ${result.submission_id}`;
  } else {
    status.textContent = "Guardrail · no answer";
    status.classList.add("declined");
  }

  const metrics = document.querySelector("#answer-metrics");
  metrics.replaceChildren();
  if (result.grounded) {
    metrics.append(
      makeElement("span", "metric", `Input tokens: ${result.input_tokens}`),
      makeElement("span", "metric", `Output tokens: ${result.output_tokens}`),
    );
  } else {
    metrics.append(makeElement("span", "metric", "The model was not called"));
  }

  document.querySelector("#source-count").textContent = `${result.sources.length} found`;
  renderSources(result.sources, document.querySelector("#sources-list"));
}

function renderReview(record) {
  const card = makeElement("article", "review-card");
  card.append(
    makeElement("p", "review-id", record.id),
    makeElement("h3", "", record.question),
    makeElement("p", "review-answer", record.answer),
  );
  if (record.sources.length) {
    const names = [...new Set(record.sources.map((source) => source.doc_name))];
    card.append(makeElement("p", "review-sources", `Sources: ${names.join(", ")}`));
  }

  const reviewerLabel = makeElement("label", "", "Reviewer name");
  const reviewer = makeElement("input");
  reviewer.type = "text";
  reviewer.maxLength = 120;
  reviewer.placeholder = "Your name";
  reviewer.required = true;
  reviewer.autocomplete = "name";

  const reasonLabel = makeElement("label", "", "Rejection reason (required to reject)");
  const reason = makeElement("input");
  reason.type = "text";
  reason.maxLength = 1000;
  reason.placeholder = "Why should this draft not be released?";

  const actions = makeElement("div", "review-actions");
  const approve = makeElement("button", "button button-approve button-small", "Approve");
  approve.type = "button";
  const reject = makeElement("button", "button button-reject button-small", "Reject");
  reject.type = "button";
  actions.append(approve, reject);
  card.append(reviewerLabel, reviewer, reasonLabel, reason, actions);

  async function decide(action) {
    if (!reviewer.value.trim()) {
      reviewer.setCustomValidity("Enter the reviewer's name.");
      reviewer.reportValidity();
      reviewer.addEventListener("input", () => reviewer.setCustomValidity(""), { once: true });
      return;
    }
    if (action === "reject" && !reason.value.trim()) {
      reason.setCustomValidity("Enter a reason for rejecting this answer.");
      reason.reportValidity();
      reason.addEventListener("input", () => reason.setCustomValidity(""), { once: true });
      return;
    }

    approve.disabled = true;
    reject.disabled = true;
    try {
      await requestJson(`/api/reviews/${encodeURIComponent(record.id)}/${action}`, {
        method: "POST",
        body: JSON.stringify({
          reviewer: reviewer.value,
          reason: action === "reject" ? reason.value : null,
        }),
      });
      showNotice(action === "approve" ? `${record.id} approved and released.` : `${record.id} rejected; it was not released.`);
      await loadPendingReviews();
    } catch (error) {
      approve.disabled = false;
      reject.disabled = false;
      showNotice(error.message, true);
    }
  }

  approve.addEventListener("click", () => decide("approve"));
  reject.addEventListener("click", () => decide("reject"));
  return card;
}

async function loadPendingReviews() {
  try {
    const records = await requestJson("/api/reviews/pending");
    pendingCount.textContent = String(records.length);
    reviewList.replaceChildren();
    if (!records.length) {
      reviewList.append(makeElement("p", "empty-state", "No drafts are waiting for review."));
      return;
    }
    for (const record of records) reviewList.append(renderReview(record));
  } catch (error) {
    reviewList.replaceChildren(makeElement("p", "empty-state", error.message));
    showNotice(error.message, true);
  }
}

askForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  notice.hidden = true;
  answerSection.hidden = true;
  askButton.disabled = true;
  askButton.querySelector("span").textContent = "Searching…";
  try {
    const result = await requestJson("/api/ask", {
      method: "POST",
      body: JSON.stringify({ question: questionInput.value }),
    });
    renderAnswer(result);
    if (result.grounded) {
      showNotice(`Draft ${result.submission_id} saved for review. It is not released yet.`);
      await loadPendingReviews();
    }
  } catch (error) {
    showNotice(error.message, true);
  } finally {
    askButton.disabled = false;
    askButton.querySelector("span").textContent = "Ask question";
  }
});

loadPendingReviews();
