"""Local web UI and API for the Module 2 RAG lab."""
from __future__ import annotations

import json
import os
import re
import sqlite3
from contextlib import closing
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator

from ingest import InMemoryIndex, ScoredChunk, load_documents
from llm import ClaudeClient, LlmClient, LlmResponse
from qa_service import RagAnswer, RagService

LAB_DIR = Path(__file__).resolve().parent
STATIC_DIR = LAB_DIR / "static"
DEFAULT_DATABASE = LAB_DIR / ".data" / "reviews.sqlite3"


class ApiKeyNotConfigured(Exception):
    """Raised only when a relevant question needs a model but no API key is set."""


class EnvironmentClaudeClient:
    """Create the Claude client only when a relevant question actually needs it."""

    def __init__(self) -> None:
        self._client: ClaudeClient | None = None

    def complete(self, system: str, user: str) -> LlmResponse:
        if not os.environ.get("ANTHROPIC_API_KEY"):
            raise ApiKeyNotConfigured
        if self._client is None:
            self._client = ClaudeClient.from_env()
        return self._client.complete(system, user)


@dataclass(frozen=True)
class ReviewRecord:
    id: str
    question: str
    answer: str
    sources: list[dict[str, Any]]
    input_tokens: int
    output_tokens: int
    status: str
    reviewer: str | None
    reason: str | None
    created_at: str
    decided_at: str | None


class ReviewStore:
    """SQLite persistence for drafts and reviewer decisions."""

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path).expanduser().resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with closing(self._connect()) as connection, connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS submissions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    question TEXT NOT NULL,
                    answer TEXT NOT NULL,
                    sources_json TEXT NOT NULL,
                    input_tokens INTEGER NOT NULL,
                    output_tokens INTEGER NOT NULL,
                    status TEXT NOT NULL CHECK (status IN ('PENDING_REVIEW', 'APPROVED', 'REJECTED')),
                    reviewer TEXT,
                    reason TEXT,
                    created_at TEXT NOT NULL,
                    decided_at TEXT
                )
                """
            )

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=10)
        connection.row_factory = sqlite3.Row
        return connection

    @staticmethod
    def _record(row: sqlite3.Row) -> ReviewRecord:
        return ReviewRecord(
            id=f"A-{row['id']:04d}",
            question=row["question"],
            answer=row["answer"],
            sources=json.loads(row["sources_json"]),
            input_tokens=row["input_tokens"],
            output_tokens=row["output_tokens"],
            status=row["status"],
            reviewer=row["reviewer"],
            reason=row["reason"],
            created_at=row["created_at"],
            decided_at=row["decided_at"],
        )

    @staticmethod
    def _row_for_id(connection: sqlite3.Connection, submission_id: str) -> sqlite3.Row | None:
        match = re.fullmatch(r"A-(\d+)", submission_id)
        if match is None:
            return None
        return connection.execute(
            "SELECT * FROM submissions WHERE id = ?", (int(match.group(1)),)
        ).fetchone()

    def save(self, answer: RagAnswer) -> ReviewRecord:
        sources = [
            {
                "doc_name": source.chunk.doc_name,
                "chunk_no": source.chunk.chunk_no,
                "text": source.chunk.text,
                "score": source.score,
            }
            for source in answer.sources
        ]
        created_at = datetime.now(timezone.utc).isoformat()
        with closing(self._connect()) as connection, connection:
            cursor = connection.execute(
                """
                INSERT INTO submissions
                    (question, answer, sources_json, input_tokens, output_tokens, status, created_at)
                VALUES (?, ?, ?, ?, ?, 'PENDING_REVIEW', ?)
                """,
                (
                    answer.question,
                    answer.answer,
                    json.dumps(sources),
                    answer.input_tokens,
                    answer.output_tokens,
                    created_at,
                ),
            )
            row = connection.execute(
                "SELECT * FROM submissions WHERE id = ?", (cursor.lastrowid,)
            ).fetchone()
            if row is None:
                raise RuntimeError("The saved review submission could not be loaded.")
            return self._record(row)

    def pending(self) -> list[ReviewRecord]:
        with closing(self._connect()) as connection:
            rows = connection.execute(
                "SELECT * FROM submissions WHERE status = 'PENDING_REVIEW' ORDER BY id"
            ).fetchall()
            return [self._record(row) for row in rows]

    def decide(
        self, submission_id: str, status: str, reviewer: str, reason: str | None
    ) -> ReviewRecord:
        decided_at = datetime.now(timezone.utc).isoformat()
        with closing(self._connect()) as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = self._row_for_id(connection, submission_id)
            if row is None:
                raise HTTPException(status_code=404, detail="Review submission not found.")
            if row["status"] != "PENDING_REVIEW":
                raise HTTPException(status_code=409, detail="This submission was already decided.")
            connection.execute(
                """
                UPDATE submissions
                SET status = ?, reviewer = ?, reason = ?, decided_at = ?
                WHERE id = ? AND status = 'PENDING_REVIEW'
                """,
                (status, reviewer, reason, decided_at, row["id"]),
            )
            updated = connection.execute(
                "SELECT * FROM submissions WHERE id = ?", (row["id"],)
            ).fetchone()
            if updated is None:
                raise RuntimeError("The updated review submission could not be loaded.")
            connection.commit()
            return self._record(updated)


class AskRequest(BaseModel):
    question: str = Field(min_length=1, max_length=2000)

    @field_validator("question")
    @classmethod
    def question_must_not_be_blank(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Enter a question.")
        return value


class DecisionRequest(BaseModel):
    reviewer: str = Field(min_length=1, max_length=120)
    reason: str | None = Field(default=None, max_length=1000)

    @field_validator("reviewer")
    @classmethod
    def reviewer_must_not_be_blank(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Enter the reviewer's name.")
        return value

    @field_validator("reason")
    @classmethod
    def normalize_reason(cls, value: str | None) -> str | None:
        return value.strip() if value is not None else None


class SourceResponse(BaseModel):
    doc_name: str
    chunk_no: int
    text: str
    score: float


class AskResponse(BaseModel):
    question: str
    answer: str
    grounded: bool
    sources: list[SourceResponse]
    input_tokens: int
    output_tokens: int
    submission_id: str | None
    status: str | None


class ReviewResponse(BaseModel):
    id: str
    question: str
    answer: str
    sources: list[SourceResponse]
    input_tokens: int
    output_tokens: int
    status: str
    reviewer: str | None
    reason: str | None
    created_at: str
    decided_at: str | None


def build_index() -> InMemoryIndex:
    index = InMemoryIndex()
    for name, text in load_documents(LAB_DIR / "sample_docs"):
        index.add_document(name, text)
    return index


def _source_response(source: ScoredChunk) -> SourceResponse:
    return SourceResponse(
        doc_name=source.chunk.doc_name,
        chunk_no=source.chunk.chunk_no,
        text=source.chunk.text,
        score=source.score,
    )


def _review_response(record: ReviewRecord) -> ReviewResponse:
    return ReviewResponse(**record.__dict__)


def create_app(
    database_path: str | Path = DEFAULT_DATABASE,
    llm_client: LlmClient | None = None,
) -> FastAPI:
    index = build_index()
    service = RagService(index, llm_client or EnvironmentClaudeClient())
    store = ReviewStore(database_path)
    web_app = FastAPI(title="Module 2 RAG Review UI")

    @web_app.get("/api/health")
    def health() -> dict[str, str]:
        return {"status": "ok"}

    @web_app.post("/api/ask", response_model=AskResponse)
    def ask(request: AskRequest) -> AskResponse:
        try:
            answer = service.ask(request.question)
        except ApiKeyNotConfigured:
            raise HTTPException(
                status_code=503,
                detail="Set ANTHROPIC_API_KEY in the server environment to answer relevant questions.",
            ) from None

        record = store.save(answer) if answer.grounded else None
        return AskResponse(
            question=answer.question,
            answer=answer.answer,
            grounded=answer.grounded,
            sources=[_source_response(source) for source in answer.sources],
            input_tokens=answer.input_tokens,
            output_tokens=answer.output_tokens,
            submission_id=record.id if record else None,
            status=record.status if record else None,
        )

    @web_app.get("/api/reviews/pending", response_model=list[ReviewResponse])
    def pending_reviews() -> list[ReviewResponse]:
        return [_review_response(record) for record in store.pending()]

    @web_app.post("/api/reviews/{submission_id}/approve", response_model=ReviewResponse)
    def approve(submission_id: str, request: DecisionRequest) -> ReviewResponse:
        record = store.decide(submission_id, "APPROVED", request.reviewer, None)
        return _review_response(record)

    @web_app.post("/api/reviews/{submission_id}/reject", response_model=ReviewResponse)
    def reject(submission_id: str, request: DecisionRequest) -> ReviewResponse:
        if not request.reason:
            raise HTTPException(status_code=422, detail="Enter a reason for rejecting this answer.")
        record = store.decide(submission_id, "REJECTED", request.reviewer, request.reason)
        return _review_response(record)

    web_app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="ui")
    return web_app


app = create_app()
